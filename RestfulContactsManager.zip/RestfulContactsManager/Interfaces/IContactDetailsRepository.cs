﻿using RestfulContactsManager.Models;
using System;
using System.Linq;

namespace RestfulContactsManager
{
    public interface IContactDetailsRepository : IDisposable
    {
        void Add(ContactDetails p);
        void Edit(ContactDetails p);
        void Remove(long Id);
        IQueryable<ContactDetails> GetContactDetails();
        ContactDetails FindById(long Id);        
    }
}
