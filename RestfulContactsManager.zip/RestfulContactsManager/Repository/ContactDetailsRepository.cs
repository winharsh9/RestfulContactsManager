﻿using System;
using System.Linq;
using RestfulContactsManager.Models;
using System.Data.Entity;

namespace RestfulContactsManager
{
    public class ContactDetailsRepository : IContactDetailsRepository, IDisposable
    {
        private ContactDetailsContext context = new ContactDetailsContext();

        public void Add(ContactDetails contactDetails)
        {
            context.Contacts.Add(contactDetails);
            context.SaveChanges();
        }

        public void Edit(ContactDetails contactDetails)
        {
            context.Entry(contactDetails).State = EntityState.Modified;           
           context.SaveChanges();            
        }

        public ContactDetails FindById(long Id)
        {
            return context.Contacts.FirstOrDefault(item => item.ContactId.Equals(Id));
        }

        public IQueryable<ContactDetails> GetContactDetails()
        {
            return context.Contacts;
        }

        public void Remove(long Id)
        {
            var contactDetails = context.Contacts.Find(Id);
            context.Contacts.Remove(contactDetails);
            context.SaveChanges();
        }

        public void Dispose()
        {
            context.Dispose();
        }
    }
}