﻿using System.Data.Entity;

namespace RestfulContactsManager.Models
{
    public class ContactDetailsContext : DbContext
    {
        public ContactDetailsContext() : base("name = ContactDetailsContext")
        { }

        public DbSet<ContactDetails> Contacts { get; set; }
    }
}