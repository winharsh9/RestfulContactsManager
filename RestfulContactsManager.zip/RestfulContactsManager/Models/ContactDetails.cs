﻿using System.ComponentModel.DataAnnotations;

namespace RestfulContactsManager.Models
{
    public class ContactDetails : IContactDetails
    {
        [Key]
        public long ContactId { get; set; }

        [Required]
        [StringLength(50)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(50)]
        public string LastName { get; set; }

        [Required]
        [StringLength(236)]
        public string Email { get; set; }

        [Required]
        [StringLength(30)]
        public string PhoneNumber { get; set; }

        public bool Status { get; set; }
    }
}