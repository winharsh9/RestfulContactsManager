﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RestfulContactsManager.Models;
using System.Net.Http.Headers;
using System.Net.Http;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.Configuration;

namespace RestfulContactsManager.Controllers
{
    public class ContactsManagerController : Controller
    {
        private HttpClient client;
        
        //The URL of the WEB API Service
        private string url = ConfigurationManager.AppSettings["WebApiUrl"];

        public ContactsManagerController()
        {
            client = new HttpClient()
            {
                BaseAddress = new Uri(url)
            };

            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<ActionResult> Index()
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var contactDetails = JsonConvert.DeserializeObject<List<ContactDetails>>(responseData);

                return View(contactDetails);
            }
            return View("Error");
        }

        public async Task<ActionResult> Details(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            HttpResponseMessage responseMessage = await client.GetAsync(url);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var contactDetails = JsonConvert.DeserializeObject<List<ContactDetails>>(responseData);
                ContactDetails contact = contactDetails.FirstOrDefault(item => item.ContactId.Equals(id));

                if (contactDetails == null || contact == null)
                {
                    return HttpNotFound();
                }

                return View(contact);
            }

            return View("Error");
        }

        //// GET: Contacts/Create
        public ActionResult Create()
        {
            return View();
        }

        //The Post method
        [HttpPost]
        public async Task<ActionResult> Create(ContactDetails contactDetails)
        {
            HttpResponseMessage responseMessage = await client.PostAsJsonAsync(url, contactDetails);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");
        }

        public async Task<ActionResult> Edit(long? id)
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var contact = JsonConvert.DeserializeObject<ContactDetails>(responseData);

                return View(contact);
            }
            return View("Error");
        }

        //// POST: Contacts/Edit/5
        //The PUT Method
        [HttpPost]
        public async Task<ActionResult> Edit(long? id, ContactDetails contact)
        {

            HttpResponseMessage responseMessage = await client.PutAsJsonAsync(url + "/" + id, contact);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");
        }

        //// GET: Contacts/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            HttpResponseMessage responseMessage = await client.GetAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                var responseData = responseMessage.Content.ReadAsStringAsync().Result;

                var contact = JsonConvert.DeserializeObject<ContactDetails>(responseData);

                return View(contact);
            }
            return View("Error");
        }

        //// POST: Contacts/Delete/5
        //The DELETE method
        [HttpPost]
        public async Task<ActionResult> Delete(int id, ContactDetails contact)
        {

            HttpResponseMessage responseMessage = await client.DeleteAsync(url + "/" + id);
            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return RedirectToAction("Error");
        }

        //// GET: Contacts/Create
        public ActionResult Error()
        {
            return View("Error");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                client.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
