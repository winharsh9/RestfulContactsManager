﻿using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web.Http;
using System.Web.Http.Description;
using RestfulContactsManager.Models;

namespace RestfulContactsManager.Controllers
{
    public class ContactDetailsController : ApiController
    {
        private IContactDetailsRepository contactDetailsRepository = null;

        public ContactDetailsController(IContactDetailsRepository repository)
        {
            contactDetailsRepository = repository;
        }

        // GET: api/ContactDetails
        public IQueryable<ContactDetails> GetContacts()
        {
            return contactDetailsRepository.GetContactDetails();
        }

        // GET: api/ContactDetails/5
        [ResponseType(typeof(ContactDetails))]
        public IHttpActionResult GetContactDetails(long id)
        {
            ContactDetails contactDetails = contactDetailsRepository.FindById(id);
            if (contactDetails == null)
            {
                return NotFound();
            }

            return Ok(contactDetails);
        }

        // PUT: api/ContactDetails/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutContactDetails(long id, ContactDetails contactDetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != contactDetails.ContactId)
            {
                return BadRequest();
            }

            try
            {
                this.contactDetailsRepository.Edit(contactDetails);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ContactDetailsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ContactDetails
        [ResponseType(typeof(ContactDetails))]
        public IHttpActionResult PostContactDetails(ContactDetails contactDetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            this.contactDetailsRepository.Add(contactDetails);

            return CreatedAtRoute("DefaultApi", new { id = contactDetails.ContactId }, contactDetails);
        }

        // DELETE: api/ContactDetails/5
        [ResponseType(typeof(ContactDetails))]
        public IHttpActionResult DeleteContactDetails(long id)
        {
            ContactDetails contactDetails = contactDetailsRepository.FindById(id);
            if (contactDetails == null)
            {
                return NotFound();
            }

            contactDetailsRepository.Remove(id);

            return Ok(contactDetails);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                contactDetailsRepository.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ContactDetailsExists(long id)
        {
            return contactDetailsRepository.FindById(id) != null ? true : false;
        }
    }
}